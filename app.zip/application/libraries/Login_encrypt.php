<?php

/**
 * Created by PhpStorm.
 * User: 52297
 * Date: 2018/10/19
 * Time: 11:40
 */
class Login_encrypt
{

	private $_private_key =
		'MIICXAIBAAKBgQDS6VbgEpOwVc8jXYx/uL6ItMS6aBPVo8fvw0pd90jLJYvfJcFJ
		dYVFh6JPRdpGhlIrED45VdsktcJvJj0cLNI5ZIZ680aS6JTFe3ScBY4Mi7bLKzBN
		YtMBtnkAFbMmWlCXV4qzZYg8+xNktY5ClZZCvZzzlaU5djtUSoxTLkxcmwIDAQAB
		AoGAZT944gZo+bynvH17JhEk/nFxA19VLjj6kSH6AFPmkQcMN2pjeIU/Hhq3k0Cg
		QTzYEy4wAMwzcFME7OC5c14c6GsnOQVEbzT3jA5lNuMnrvb+ehyE0w/O7ah8sSLQ
		3B42GFKkaKiuY2ufsVC4pv6LMn5Sh26ApW332yO0dXZXagECQQDvAWV+n41R9pUp
		iB0+ycBvkuE6yjlohc2MqAxdD+EYNgO4jb1F21pZcqasd/SbpiQwVUKk/uxlOvl9
		3dBlcOWbAkEA4eiMv8UiGwBxjBGrz+I/tBq56gcnjvlOkJFyAyxbKaA1C9C51eVv
		39OftI9DqCzcuAYZsCmspb6XEPBIB01VAQJAZVyAQM1Fz+b1p6F0VbaWiDsQjjBJ
		XIyyed6jL6yWWABAX7qs9L1sedbn3OkashAp9N2T4AnFE8GJIdo6kWrp1QJAGOiF
		LFfWDNgdrO393av6jicsPIuRZwhCC1qeEY+AdbR+ZNEczGLB1RIGV+g7830O0ROL
		HYtax+Od0HZN2tBCAQJBANIg+HO5+Qy5hgRO3+uRHERgUQxqHzheLdo5GnoQ/sfT
		sex4mxgze6oq+HldvNWzVjBu9g9417T5WMgyWQ8Unhw=';

	private $_public_key =
		'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDS6VbgEpOwVc8jXYx/uL6ItMS6
		aBPVo8fvw0pd90jLJYvfJcFJdYVFh6JPRdpGhlIrED45VdsktcJvJj0cLNI5ZIZ6
		80aS6JTFe3ScBY4Mi7bLKzBNYtMBtnkAFbMmWlCXV4qzZYg8+xNktY5ClZZCvZzz
		laU5djtUSoxTLkxcmwIDAQAB';

	private $_pikey;
	private $_pukey;

	/**
	 * encryptRSA constructor.
	 */
	public function __construct()
	{
		$this->_pikey = openssl_pkey_get_private($this->_private_key);
		$this->_pukey = openssl_pkey_get_public($this->_public_key);
	}

	public function get_public_key()
	{
		return $this->_pukey;
	}

	/**
	 * do public encrypt.
	 * @param $data
	 * @return mixed
	 */
	public function public_encrypt($data)
	{
		openssl_public_encrypt($data, $encrypted, $this->_pukey);
		return $encrypted;
	}

	/**
	 * do public decrypt.
	 * @param $data
	 * @return mixed
	 */
	public function public_decrypt($data)
	{
		openssl_public_decrypt($data, $decrpyted, $this->_pukey);
		return $decrpyted;
	}

	/**
	 * do private encrypt.
	 * @param $data
	 * @return mixed
	 */
	public function private_encrypt($data)
	{
		openssl_private_encrypt($data, $encrypted, $this->_pikey);
		return $encrypted;
	}

	/**
	 * do private decrypted.
	 * @param $data
	 * @return mixed
	 */
	public function private_decrypt($data)
	{
		openssl_private_decrypt($data, $decrypted, $this->_pikey);
		return $decrypted;
	}
}
