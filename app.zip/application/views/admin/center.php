<?php
/**
 * Created by PhpStorm.
 * User: 52297
 * Date: 2018/10/18
 * Time: 23:03
 */

defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div style="width: 100%; margin: 15px;">
	<div style="padding-left:35px;">
		<h2>欢迎来到管理面板。</h2>
		<div>
			PHP版本：<?php echo phpversion(); ?>
		</div>
	</div>
</div>


