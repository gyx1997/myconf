<?php
/**
 * Created by PhpStorm.
 * User: 52297
 * Date: 2018/10/21
 * Time: 18:57
 */

defined('BASEPATH') OR exit('No direct script access allowed') ?>
</div>
</div>
</div>

<?php if ($op == 'submit') echo '<script type="text/javascript">setTimeout(function(){window.location.href="/admin/' . $mod . '/";}, 3000)</script>'; ?>
