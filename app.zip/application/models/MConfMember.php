<?php
/**
 * Created by PhpStorm.
 * User: 52297
 * Date: 2018/11/11
 * Time: 13:37
 */
class mConfMember extends CF_Model {
    public function __construct(){
        parent::__construct();
        $this->_table_name = 'conference_members';
    }

    public function get_conference_members($conference_id, $start = 0, $limit = 0){
        return $this->_fetch_all(
            array('conference_id' => $conference_id),
            '',
            '',
            $start,
            $limit
        );
    }

    public function get_conference_members_by_role(){

    }

    public function get_user_conferences($user_id, $start = 0, $limit = 10){
        return $this->_fetch_all(
            array('user_id' => $user_id),
            '',
            '',
            $start,
            $limit
        );
    }
}