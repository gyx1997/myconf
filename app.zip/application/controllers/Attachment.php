<?php
/**
 * Created by PhpStorm.
 * User: 52297
 * Date: 2018/10/23
 * Time: 16:31
 */

class attachment extends CF_Controller
{
	private $result = array();

	public function __construct()
	{
		parent::__construct();
	}

	public function upload()
	{
		switch ($this->_action) {
			case 'file':
			case 'image':
				{
					$file = $_FILES['upfile'];
					if (!$file || $file['error'] != 0) {
						$this->result = array('state' => 'ERROR_FILE_NOT_FOUND');
						break;
					}

					if (!file_exists($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
						$this->result = array('state' => 'ERROR_TMP_FILE_NOT_FOUND');
						break;
					}

					$stored_data = $this->get_file_stored_data($file['name']);
					$file_size = filesize($file['tmp_name']);

					if ($this->move_file_to($file['tmp_name'], $stored_data['stored_dir'], $stored_data['short_name']) === FALSE) {
						$this->result = array('state' => 'ERROR_WRITE_CONTENT');
						return;
					}

					$is_image = ($stored_data['ext'] == '.jpg' || $stored_data['ext'] == '.jpeg'
						|| $stored_data['ext'] == '.png' || $stored_data['ext'] == '.gif') ? TRUE : FALSE;

					if ($is_image) {
						$image_info = getimagesize(FCPATH . $stored_data['stored_dir'] . $stored_data['short_name']);
					}

					$this->mAttachment->add_attachment(
						$stored_data['full_name'],
						$file_size,
						$file['name'],
						intval($this->input->post('document_id')),
						$is_image,
						0,
						1
					);

					$this->result = array(
						'state' => 'SUCCESS',
						'url' => $stored_data['stored_dir'] . $stored_data['short_name'],
						'title' => $stored_data['short_name'],
						'original' => $file['name'],
						'type' => $stored_data['ext'],
						'size' => $file_size
					);
					break;
				}
		}
		$this->return_json();
		return;
	}

	private function get_file_stored_data($file_name)
	{
		$file_ext = $this->get_file_extension($file_name);
		$t = time();
		$d = explode('-', date("Y-y-m-d-H-i-s"));
		$format = '/data/attachment/{yy}/{mm}/{dd}/';
		$format = str_replace("{yyyy}", $d[0], $format);
		$format = str_replace("{yy}", $d[1], $format);
		$format = str_replace("{mm}", $d[2], $format);
		$format = str_replace("{dd}", $d[3], $format);
		$stored_dir = $format;
		$short_name = strval($d[4]) . strval($d[5]) . strval($d[6]) . uniqid() . $file_ext;
		$full_path = $stored_dir . $short_name;
		return array(
			'full_name' => $full_path,
			'short_name' => $short_name,
			'stored_dir' => $stored_dir,
			'ext' => $file_ext,
		);
	}

	private function get_file_extension($file_name)
	{
		return strtolower(strrchr($file_name, '.'));
	}

	private function move_file_to($source_file, $directory, $file_name)
	{
		$destination_dir = FCPATH . $directory;

		if (!is_dir($destination_dir) && !mkdir($destination_dir, 0777, true)) {
			return FALSE;
		}

		if (!move_uploaded_file($source_file, $destination_dir . $file_name) ||
			!file_exists($destination_dir . $file_name)) {
			return FALSE;
		}
		return TRUE;
	}

	private function return_json()
	{
		header("Content-Type: text/html; charset=utf-8");
		$callback = $this->input->get('callback');
		echo isset($callback) ?
			htmlspecialchars($callback) . '(' . json_encode($this->result) . ')' :
			json_encode($this->result);
	}

	public function get_list()
	{
		$limit = $this->input->get('size');
		$start = $this->input->get('start');
		$files = $this->mAttachment->get_file_list(
			($this->_action == 'image'),
			$start,
			$limit
		);
		if (empty($files)) {
			$this->result = array(
				'state' => 'no match file',
				'list' => array(),
				'start' => $start,
				'total' => 0
			);
		} else {
			$file_list = array();
			foreach ($files as $file) {
				$file_list [] = array(
					'url' => $file['attachment_file_name'],
					'mtime' => $file['attachment_upload_time'],
					'original' => $file['attachment_original_name'],
				);
			}
			$this->result = array(
				'state' => 'SUCCESS',
				'list' => $file_list,
				'start' => $start,
				'total' => count($file_list)
			);
		}
		$this->return_json();
		return;
	}

	private function get_file_short_name($file_full_name)
	{
		return substr(
			$file_full_name,
			strrpos($file_full_name, '/') + 1
		);
	}

}
