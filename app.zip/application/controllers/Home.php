<?php
/**
 * Created by PhpStorm.
 * User: 52297
 * Date: 2018/11/12
 * Time: 16:47
 */
class Home extends CF_Controller{
    public function index(){
        header('location:/conference/csqrwc2019/');
    }
}