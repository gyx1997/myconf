<?php
/**
 * Created by PhpStorm.
 * User: 52297
 * Date: 2018/10/28
 * Time: 10:38
 */

class mUser extends CF_Model{
    public function __construct(){
        parent::__construct();
        $this->_table_name = 'users';
    }

    public function add_user($username, $password, $email, $salt){
        $this->db->insert(
            $this->_table(),
            array(
                'user_name' => $username,
                'user_email' => $email,
                'user_password' => $password,
                'password_salt' => $salt,
                'is_frozen' => 1,
                'user_extra' => serialize(
                    array(
                        'avatar' => '',
                        'organization' => '',
                    )
                ),
            )
        );
        return $this->db->insert_id();
    }

    public function activate_user($user_id){
        $this->db->where('user_id', $user_id);
        $this->db->update(
            $this->_table(),
            array('is_frozen' => 0)
        );
    }

    /**
     * @param string $username
     * @param string $role
     * @return mixed
     */
    public function find_user_by_name_and_role($username = NULL, $role = NULL){

        $order_by_clause = ' ORDER BY user_id DESC';

        if(($username === NULL && $role === NULL) || ($username == '' && $role == 'none')){
            $sql_str = 'SELECT * FROM ' . $this->_table() . $order_by_clause;
        } else {
            $where_str = array();
            if($username !== NULL && $username != ''){
                $where_str []= ' `user_name` LIKE "%' . $username . '%" ';
            }
            if($role !== NULL && $role != 'none'){
                $where_str []= ' `user_role` = "' . $role . '" ';
            }
            $sql_str = 'SELECT * FROM ' . $this->_table() . ' WHERE ' . implode('AND', $where_str) . $order_by_clause;
        }

        $query_result = $this->db->query($sql_str);
        return $query_result->result_array();
    }

    public function get_user_by_username($username){
        return $this->_get_single_user('user_name', $username);
    }

    public function get_user_by_email($email){
        return $this->_get_single_user('user_email', $email);
    }

    public function exists_username($username){
        return $this->_exists_single_user('user_name', $username);
    }

    public function exists_email($email){
        return $this->_exists_single_user('user_email', $email);
    }

    private function _exists_single_user($field, $value){
        return $this->_exists(array($field => $value));
    }

    private function _get_single_user($field, $value){
        $this->db->where($field, $value);
        $query = $this->db->get($this->_table());
        $result = $query->row_array();
        if(empty($result)){
            return array();
        } else {
            $result['user_extra'] = unserialize($result['user_extra']);
            return $result;
        }
    }
}