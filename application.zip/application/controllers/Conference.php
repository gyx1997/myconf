<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Conference extends CF_Controller
{
    private $_conference_data = array();
    private $_conference_url = '';
    private $_conference_id = 0;
    private $_mod = '';

    /**
     * Conference constructor.
     */
    public function __construct()
    {
        parent::__construct();
        //处理URL段
        $this->_conference_url = $this->uri->segment(2, '');
        $this->_mod = $this->uri->segment(3, '');
        $this->_action = $this->uri->segment(4, '');
        //验证conference_url合法性
        if($this->_conference_url == '' ||
            $this->mConference->has_conference_by_url($this->_conference_url) === FALSE){
            //TODO: 显示404页面，即未找到该会议。
            exit();
        }
        //处理会议信息
        $this->_conference_data = $this->mConference->get_conference_by_url($this->_conference_url);
        $this->_conference_id = $this->_conference_data['conference_id'];
    }

    /**
     * Conference Controller Module. Entry.
     */
    public function index()
    {
        switch ($this->_mod) {
            case 'document':
                {
                    $this->_document_handler();
                    break;
                }
            case 'paper':
                {
                    $this->_paper_handler();
                    break;
                }
            case 'management':
                {
                    $this->_management_handler();
                    break;
                }
            default:
                {
                    $this->_default_handler();
                }
        }
    }

    private function _management_handler(){
        //TODO:权限检测
        switch($this->_action){
            case '':
            case 'overview':
                {
                    if($this->_do == 'submit') {
                        //处理POST数据并进行合法性检测
                        if (!$this->mConference->has_conference_by_id($this->input->post('conference_id'))) {
                            $this->_exit_with_json(array('status' => 'ACCESS_DENIED'));
                        }

                        $date_ymd = explode('-', $this->input->post('conference_date_text'));
                        if(count($date_ymd) != 3){
                            $this->_exit_with_json(array('status' => 'WRONG_DATE'));
                        }

                        $conf_date = mktime(
                            0, 0, 0,
                            $date_ymd[1],
                            $date_ymd[2],
                            $date_ymd[0]
                        );

                        if ($conf_date == FALSE) {
                            $this->_exit_with_json(array('status' => 'WRONG_DATE'));
                        }

                        $conf_title = trim($this->input->post('conference_name_text'));
                        $host = $this->input->post('conference_host_text');

                        if ($conf_title == '') {
                            $this->_exit_with_json(array('status' => 'TITLE_NULL'));
                        }

                        $conf_old_data = $this->mConference->get_conference_by_id($this->input->post('conference_id'));

                        $banner_image = $conf_old_data['banner_image'];
                        $qrcode_image = $conf_old_data['qr_code'];

                        //上传图片
                        $image_param['upload_path'] = STATIC_IMG_DIR;
                        $image_param['allowed_types'] = 'jpeg|jpg|png';
                        $image_param['max_size'] = '1048576';
                        $this->load->library('upload', $image_param);

                        if ($this->upload->do_upload('banner_image')) {
                            $image_data = $this->upload->data();
                            $new_image_name = $this->_conference_url . '_banner_' . strval(rand(1000,9999)) .  $image_data['file_ext'];
                            @unlink(STATIC_IMG_DIR . $banner_image);
                            rename($image_data['full_path'], STATIC_IMG_DIR . $new_image_name);
                            $banner_image = $new_image_name;
                        }

                        if ($this->upload->do_upload('qr_code')) {
                            $image_data = $this->upload->data();
                            $new_image_name = $this->_conference_url . '_qrcode_' . strval(rand(1000,9999)) . $image_data['file_ext'];
                            @unlink(STATIC_IMG_DIR . $qrcode_image);
                            rename($image_data['full_path'], STATIC_IMG_DIR . $new_image_name);
                            $qrcode_image = $new_image_name;
                        }

                        $this->mConference->update_conference(
                            $this->input->post('conference_id'),
                            $conf_title,
                            $conf_date,
                            $banner_image,
                            $qrcode_image,
                            $host
                        );

                        $this->_exit_with_json(
                            array(
                                'status' => 'SUCCESS',
                                'banner' => $banner_image == '' ? 'FAILED' : 'SUCCESS',
                                'qr_code' => $banner_image == '' ? 'FAILED' : 'SUCCESS',
                            )
                        );
                    } else {
                        $conf_data = $this->mConference->get_conference_by_url($this->_conference_url);
                        $this->_render(
                            'conference/management/general',
                            'Management',
                            array(
                                'conference' => $this->_conference_data
                            )
                        );
                    }
                    break;
                }
            case 'category':
                {
                    switch($this->_do)
                    {
                        case'add':
                            {
                                //处理POST数据并进行合法性检测
                                if (!$this->mConference->has_conference_by_id($this->input->post('conference_id'))) {
                                    $this->_exit_with_json(array('status' => 'ACCESS_DENIED'));
                                }

                                $this->mCategory->begin_transaction();
                                $category_id = $this->mCategory->add_category(
                                    $this->input->post('conference_id'),
                                    $this->input->post('category_name_text'),
                                    intval($this->input->post('category_type_id'))
                                );
                                $this->mDocument->add_document($category_id, '', '');
                                $this->mCategory->end_transaction();
                                $this->_exit_with_json(array('status' => 'SUCCESS'));
                                break;
                            }
                        case 'up':
                            {
                                $category_id = $this->input->get('cid');
                                if($category_id != '' && $this->mCategory->has_category(intval($category_id))) {
                                    $categories = $this->mCategory->get_all_categories($this->_conference_id, TRUE);
                                    $i = 0;
                                    foreach ($categories as $category) {
                                        if ($category['category_id'] == $category_id) {
                                            break;
                                        }
                                        $i++;
                                    }
                                    if ($i != 0) {
                                        $j = 0;
                                        foreach ($categories as $category) {
                                            $this->mCategory->set_category_display_order(
                                                $category['category_id'],
                                                $j == $i - 1 ? $i : ($j == $i ? $i - 1 : $j)
                                            );
                                            $j++;
                                        }
                                    }
                                }
                                header('/conference/' . $this->_conference_url . '/management/category/');
                                break;
                            }
                        case 'down':
                            {
                                header('/conference/' . $this->_conference_url . '/management/category/');
                                break;
                            }
                        default:
                            {
                                $cat_data = $this->mCategory->get_all_categories($this->_conference_id);
                                $this->_render('conference/management/category', 'Categories', array('category_list' => $cat_data));
                            }
                    }

                    break;
                }
            case 'user':
                {
                    break;
                }
        }
    }

    private function _paper_handler(){
        switch($this->_action){
            case 'submit':
                {
                    break;
                }
            case 'submit-post':
                {
                    break;
                }
            case 'review':
                {
                    break;
                }
            case 'review-post':
                {
                    break;
                }
            case '':
            default:
                {

                }
        }
    }

    private function _default_handler(){
        $category_id = $this->input->get('cid');
        if (empty($category_id) || $category_id == NULL) {
            $category_id = $this->mCategory->get_first_category_id($this->_conference_data['conference_id']);
        }
        $categories = $this->mCategory->get_all_categories($this->_conference_data['conference_id'], TRUE);
        $category_document = $this->mDocument->get_first_document_from_category($category_id);


        $this->_render(
            'conference',
            $this->mConfig->get_title(),
            array(
                'conference' => $this->_conference_data,
                'category_list' => $categories,
                'active_category_id' => $category_id,
                'active_category_document_id' => $category_document['document_id'],
                'active_document_content' => $category_document['document_html'],
            )
        );
    }

    private function _document_handler(){
        switch($this->_action){
            case 'edit':
                {

                }
            case 'get':
            default:
            {
                $document_id = intval($this->input->get('id'));
                if (empty($document_id) || $document_id == NULL || $document_id == 0) {
                    echo '';
                }
                $document = $this->mDocument->get_document($document_id);
                if (empty($document)) {
                    echo '';
                }
                echo $document['document_html'];
                break;
            }
        }
    }

    public function _render($body_view, $title = '', $arguments = array()){
        $this->load->view(
            'common/header',
            array(
                'title' => $this->mConfig->get_title() . ' - ' . $title,
                'banner' => $this->mConfig->get_banner(),
                'login_status' => $this->_has_login(),
                'login_user' => $this->_login_status['current_user']
            )
        );
        $this->load->view(
            'conference/header',
            array(
                'conference' => $this->_conference_data,
                'tab_page' => $this->_mod,
            )
        );
        $this->load->view(
            $body_view,
            array_merge(
                $arguments,
                array(
                    'csrf_name' => $this->security->get_csrf_token_name(),
                    'csrf_hash' => $this->security->get_csrf_hash(),
                    'action' => $this->_action,
                )
            )
        );
        $this->load->view(
            'conference/footer'
        );
        $this->load->view(
            'common/footer',
            array(
                'footer1' => $this->mConfig->get_footer1(),
                'footer2' => $this->mConfig->get_footer2(),
                'mitbeian' => $this->mConfig->get_mitbeian()
            )
        );
    }
}
