<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
 * email configuration
 */

$config['useragent'] = 'CSQRWC';
$config['protocol'] = 'smtp';
$config['smtp_host'] = 'smtp.126.com';
$config['smtp_user'] = 'csqrwc@126.com';
$config['smtp_pass'] = 'csqrwc123456smtp';
$config['mailtype'] = 'html';
