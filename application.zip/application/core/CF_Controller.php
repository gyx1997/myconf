<?php
/**
 * Created by PhpStorm.
 * User: 52297
 * Date: 2018/10/20
 * Time: 20:12
 */

class CF_Controller extends CI_Controller
{
    protected $_login_status = array();
    protected $_parameters = array();
    protected $_action = '';
    protected $_do = '';

    protected function _check_login(){
        $this->_login_status = $this->session->userdata('login_status');
        if(empty($this->_login_status)){
            return FALSE;
        }
        return TRUE;
    }

    protected function _has_login(){
        return !empty($this->_login_status);
    }

    protected function _set_login($user_data){
        $this->session->set_userdata(
            'login_status',
            array(
                'login_time' => time(),
                'current_user' => $user_data
            )
        );
    }

	/**
	 * CF_Controller constructor.
	 */
	public function __construct()
	{
		parent::__construct();
		$this->load->library('session');
		$this->load->model('mConfig');
		$this->load->model('mCategory');
		$this->load->model('mAttachment');
		$this->load->model('mDocument');
		$this->load->model('mUser');
		$this->load->model('mConference');
		$this->load->helper('url');
		//cook parameters
        $this->_action = $this->uri->segment(3, '');
        $this->_do = $this->input->get('do');
        $this->_check_login();
	}



	/**
	 * @param string $body_view
	 * @param string $title
	 * @param array $arguments
	 */
	protected function _render($body_view, $title = '', $arguments = array())
	{
		$this->load->view(
			'common/header',
			array(
				'title' => $this->mConfig->get_title() . ' - ' . $title,
				'banner' => $this->mConfig->get_banner(),
                'login_status' => $this->_has_login(),
                'login_user' => $this->_login_status['current_user']
			)
		);
		$this->load->view(
			$body_view,
			array_merge(
				$arguments,
				array(
					'csrf_name' => $this->security->get_csrf_token_name(),
					'csrf_hash' => $this->security->get_csrf_hash(),
					'op' => $this->uri->segment(3),
				)
			)
		);
		$this->load->view(
			'common/footer',
			array(
				'footer1' => $this->mConfig->get_footer1(),
				'footer2' => $this->mConfig->get_footer2(),
				'mitbeian' => $this->mConfig->get_mitbeian()
			)
		);
	}

    /**
     * @param string $body_view
     * @param string $title
     * @param array $arguments
     */
    protected function _render_admin($body_view, $title = '', $arguments = array())
    {
        $this->load->view(
            'common/header',
            array(
                'title' => $this->mConfig->get_title() . ' - ' . $title,
                'banner' => $this->mConfig->get_banner(),
            )
        );
        $this->load->view(
            'admin/header',
            array(
                'mod' => $this->uri->segment(2)
            )
        );
        $this->load->view(
            $body_view,
            array_merge(
                $arguments,
                array(
                    'csrf_name' => $this->security->get_csrf_token_name(),
                    'csrf_hash' => $this->security->get_csrf_hash(),
                    'op' => $this->uri->segment(3),
                )
            )
        );
        $this->load->view(
            'admin/footer',
            array(
                'mod' => $this->uri->segment(2)
            )
        );
        $this->load->view(
            'common/footer',
            array(
                'footer1' => $this->mConfig->get_footer1(),
                'footer2' => $this->mConfig->get_footer2(),
                'mitbeian' => $this->mConfig->get_mitbeian()
            )
        );
    }

    protected function _send_mail(){

    }

    protected function _exit_with_json($parameters = array()){
        header('Content-Type:application/json;charset=utf-8');
        echo json_encode($parameters);
        exit(0);
    }
}

