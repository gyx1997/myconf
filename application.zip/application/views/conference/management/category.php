<?php
/**
 * Created by PhpStorm.
 * User: 52297
 * Date: 2018/11/11
 * Time: 20:07
 */

defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="col-md-2 content-lf">
    <a class="btn btn-block btn-light content-lf-btn"
       href="/conference/<?php echo $conference['conference_url'];?>/management/overview/">
        Overview
    </a>
    <span class="btn btn-block btn-light active content-lf-btn">
        Categories
    </span>
    <a class="btn btn-block btn-light content-lf-btn"
       href="/conference/<?php echo $conference['conference_url'];?>/management/participant/">
        Participants
    </a>
    <a class="btn btn-block btn-light content-lf-btn"
       href="/conference/<?php echo $conference['conference_url'];?>/management/attachment/">
        Attachments
    </a>
</div>
<div class="col-md-10 content-rf">
    <div class="col-md-12">
        <div class="row">
            <div class="row mt-3"/>
            <div class="col-md-12  col-md-offset-1 form-horizontal">
                <div class="col-md-12">
                    <form id="form_data" role="form"
                          action="/conference/<?php echo $conference['conference_url'];?>/management/category/?do=add"
                          method="post" enctype="multipart/form-data"
                          onkeydown="if(event.keyCode==13){return false;}"
                          >
                        <input type="hidden" name="<?php echo $csrf_name; ?>" value="<?php echo $csrf_hash; ?>"/>
                        <input type="hidden" name="conference_id" value="<?php echo $conference['conference_id'];?>"/>
                        <div class="row form-inline">

                            <label for="category_name_text" class="col-md-3">
                                Category Name
                            </label>
                            <input class="form-control col-md-4" type="text" name="category_name_text" id="category_name_text"/>
                            <label for="category_type_id" class="col-md-1">
                                Type
                            </label>
                            <select disabled="disabled" name="category_type_id" class="form-control col-md-3">
                                <option value="0" selected="selected">Single document</option>
                                <option value="1">Document list</option>
                            </select>
                            <button type="button" class="btn btn-secondary col-md-1" onclick="submitForm();return false;">Add</button>

                        </div>
                        <div class="row mt-3"></div>
                        <div class="row">
                            <div class="col-md-7"></div>
                            <div class="col-md-4 alert alert-info">'Single document' only now.</div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row mt-3"/>
            <div class="col-md-12 col-md-offset-1 form-horizontal">
                <table class="table table-hover">
                    <thead>
                    <tr>
                        <th>栏目标题</th>
                        <th>栏目类型</th>
                        <th></th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($category_list as $cat) { ?>
                        <tr>
                            <form id="category_<?php echo $cat['category_id']; ?>" role="form"
                                  action="/admin/category/mod-cat/<?php echo $cat['category_id'] ?>/" method="post"
                                  enctype="multipart/form-data">
                                <input type="hidden" name="<?php echo $csrf_name; ?>"
                                       value="<?php echo $csrf_hash; ?>"/>
                                <td>
                                    <div class="form-inline">
                                        <input name="category_name_text" id="category_name_text" type="text"
                                               class="form-control" value="<?php echo $cat['category_title']; ?>"/>
                                        &nbsp;&nbsp;
                                        <button type="submit" class="btn"
                                                onclick="window.location.href='/admin/category/mod-cat/<?php echo $cat['category_id']; ?>/'">
                                            修改
                                        </button>
                                    </div>
                                </td>
                                <td>
                                    <?php if ($cat['category_type'] == 0) { ?>
                                        <select disabled="disabled" name="category_type_id" class="form-control">
                                            <option value="0" selected="selected">只包含一篇文档</option>
                                            <option value="1">多篇文档显示的列表</option>
                                        </select>
                                    <?php } else { ?>
                                        <select disabled="disabled" name="category_type_id" class="form-control">
                                            <option value="0">只包含一篇文档</option>
                                            <option value="1" selected="selected">多篇文档显示的列表</option>
                                        </select>
                                    <?php } ?>
                                </td>
                                <td>
                                    <button type="button" class="btn"
                                            onclick="window.location.href='/admin/category/up-cat/<?php echo $cat['category_id']; ?>/'">
                                        上移
                                    </button>
                                    <button type="button" class="btn"
                                            onclick="window.location.href='/admin/category/down-cat/<?php echo $cat['category_id']; ?>/'">
                                        下移
                                    </button>
                                </td>
                                <td>
                                    <button type="button" class="btn"
                                            onclick="window.location.href='/admin/category/del-cat/<?php echo $cat['category_id']; ?>/'">
                                        删除
                                    </button>
                                    <?php if ($cat['category_type'] == 0) { ?>
                                        <button type="button" class="btn"
                                                onclick="window.location.href='/admin/category/mod-doc/<?php echo $cat['category_id']; ?>/'">
                                            编辑文章
                                        </button>
                                    <?php } else { ?>
                                        <button type="button" class="btn"
                                                onclick="window.location.href='/admin/category/mod-doc-list/<?php echo $cat['category_id']; ?>/'">
                                            编辑文章列表
                                        </button>
                                    <?php } ?>
                                </td>
                            </form>
                        </tr>
                    <?php } ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
</div>
<script type="text/javascript">
    function submitForm() {
        $.ajax({
            async: true,
            type: "POST",
            url: "/conference/<?php echo $conference['conference_url'];?>/management/category/?do=add",
            contentType: "application/x-www-form-urlencoded; charset=utf-8",
            data: $('#form_data').serialize(),
            dataType : "text",
            processData: false,
            cache: false,
            success: function (data_result) {
                var d = eval("(" + data_result + ")");
                if (d.status === 'SUCCESS') {
                    window.location.href = "/conference/<?php echo $conference['conference_url'];?>/management/category/";
                }
            },
            error: function () {

            }
        });
        return false;
    }
</script>
