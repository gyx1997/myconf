<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div id="body">
    <div style="padding-left:35px;text-align: left;">
        <form id="paper_data" name="paper_data" action="/conference/paper/submit-end/"
              method="post" enctype="multipart/form-data">
            <input type="hidden" name="<?php echo $csrf_name; ?>" value="<?php echo $csrf_hash; ?>"/>
            <input type="hidden" name="user_id" value="<?php echo $user['user_id'];?>"/>
            <div class="form-group">
                <label for="paper_title_text">Title</label>&nbsp;&nbsp;&nbsp;
                <div class="alert alert-info">
                    Title should be NO MORE than 200 characters.
                </div>
                <textarea class="form form-control" id="paper_title_text" name="paper_title_text" rows="2"></textarea>
            </div>
            <div class="page-header"><h1></h1></div>
            <div class="form-group">
                <label for="paper_abstract_text">Abstract</label>&nbsp;&nbsp;&nbsp;
                <div class="alert alert-info">
                    Abstract should be NO MORE than 200 words.
                </div>
                <textarea class="form form-control" id="paper_abstract_text" name="paper_abstract_text" rows="2"></textarea>
            </div>

            <button id="submit_button" class="btn btn-success" type="submit">Submit</button>
        </form>
    </div>
</div>



